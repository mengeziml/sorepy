# sorepy
This package assists the user in recursively sorting arrays and getting fibonacci terms,
factorials and also reversing strings.

## building this package locally
`python setup.py sdist`

## installing this package from GitHub
`pip install git+https://github.com/mengeziml/sorepy.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/mengeziml/sorepy.git`
